var dir_d522931ffa1371640980b621734a4381 =
[
    [ "Taras", "dir_d06c780d956c7300dc6cc10fb1ebe54d.html", "dir_d06c780d956c7300dc6cc10fb1ebe54d" ]
];