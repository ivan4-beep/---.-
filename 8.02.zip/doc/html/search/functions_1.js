var searchData=
[
  ['dog_25',['Dog',['../classdomain_1_1_dog.html#abaf368c7d0bf61ef8205ad3f981bdfa8',1,'domain.Dog.Dog(String Name, int age, String kind)'],['../classdomain_1_1_dog.html#ad1c8964368cb6ccdaf60087654fb3b80',1,'domain.Dog.Dog()'],['../classdomain_1_1_dog.html#ab14c9378199dc9a6eaddd66e1c616956',1,'domain.Dog.Dog(String Name)']]]
];
