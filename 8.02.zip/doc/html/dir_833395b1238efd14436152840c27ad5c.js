var dir_833395b1238efd14436152840c27ad5c =
[
    [ "Animal.java", "_animal_8java.html", [
      [ "Animal", "classdomain_1_1_animal.html", "classdomain_1_1_animal" ]
    ] ],
    [ "Dog.java", "_dog_8java.html", [
      [ "Dog", "classdomain_1_1_dog.html", "classdomain_1_1_dog" ]
    ] ]
];