var annotated_dup =
[
    [ "domain", "namespacedomain.html", [
      [ "Animal", "classdomain_1_1_animal.html", "classdomain_1_1_animal" ],
      [ "Dog", "classdomain_1_1_dog.html", "classdomain_1_1_dog" ]
    ] ],
    [ "test", "namespacetest.html", [
      [ "TestAnimal", "classtest_1_1_test_animal.html", null ]
    ] ]
];