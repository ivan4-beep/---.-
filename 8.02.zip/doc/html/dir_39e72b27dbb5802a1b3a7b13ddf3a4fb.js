var dir_39e72b27dbb5802a1b3a7b13ddf3a4fb =
[
    [ "Документи", "dir_2c047d77c77238eb2ca7f9281b414a36.html", "dir_2c047d77c77238eb2ca7f9281b414a36" ]
];