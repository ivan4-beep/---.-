var searchData=
[
  ['play_11',['play',['../classdomain_1_1_animal.html#a1b42c62d3efcaf1c517784c995153485',1,'domain.Animal.play()'],['../classdomain_1_1_dog.html#af5196733085185dd8d1b41f79cc3db7a',1,'domain.Dog.play()']]]
];
