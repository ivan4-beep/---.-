var hierarchy =
[
    [ "domain.Animal", "classdomain_1_1_animal.html", [
      [ "domain.Dog", "classdomain_1_1_dog.html", null ]
    ] ],
    [ "test.TestAnimal", "classtest_1_1_test_animal.html", null ]
];