var classdomain_1_1_animal =
[
    [ "Animal", "classdomain_1_1_animal.html#acfbf1405e335fb7887eba1f22cf484c2", null ],
    [ "eat", "classdomain_1_1_animal.html#aeb4cdcb2e2faa803e125dea86486e474", null ],
    [ "play", "classdomain_1_1_animal.html#a1b42c62d3efcaf1c517784c995153485", null ],
    [ "toString", "classdomain_1_1_animal.html#a1b29e1c4522c9593ac169ea0b113fa07", null ],
    [ "age", "classdomain_1_1_animal.html#a726752b300deaf898df2dd944fce8659", null ],
    [ "Name", "classdomain_1_1_animal.html#a91f6712957c95d2dc618703d7e149441", null ]
];