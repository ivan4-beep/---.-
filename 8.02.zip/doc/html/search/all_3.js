var searchData=
[
  ['guarded_7',['guarded',['../classdomain_1_1_dog.html#a5cd41d0dde9b042dca1eb8fd85863f51',1,'domain::Dog']]]
];
