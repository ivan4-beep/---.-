var searchData=
[
  ['kind_8',['kind',['../classdomain_1_1_dog.html#a866cfec5d1afff4b13b9ec225f47389c',1,'domain::Dog']]]
];
